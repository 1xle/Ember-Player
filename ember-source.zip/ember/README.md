<div align="center">

<img src="docs/banner.png" alt="Ember" width="100%">

# Ember

Streams free, legally licensed music. Plays your own MP3s. Looks how you want
it to. Runs in about **60 MB of RAM**, because it doesn't ship a second copy of
Chrome.

[![Build](https://github.com/YOUR-USERNAME/ember/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR-USERNAME/ember/actions/workflows/ci.yml)
[![Release](https://img.shields.io/github/v/release/YOUR-USERNAME/ember?include_prereleases)](https://github.com/YOUR-USERNAME/ember/releases)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Built with Tauri](https://img.shields.io/badge/built%20with-Tauri%202-24C8DB)](https://tauri.app)

[Download](#download) · [Build from source](#build-from-source) · [How it works](#how-it-works) · [FAQ](#faq)

</div>

---

## Screenshots

> **Add yours here.** Run `npm run dev`, size the window to about 1280x800,
> screenshot it, and save it as `docs/screenshot-player.png`. Then delete this
> quote block and uncomment the line below.

<!-- ![The player](docs/screenshot-player.png) -->

---

## Features

- **Free catalogue.** Hundreds of thousands of tracks from the [Audius](https://audius.co) network — independent electronic, hip-hop, house, lo-fi, drum &amp; bass. No account, no API key, no ads.
- **Your own files.** Point Ember at your music folder. It scans every subfolder, reads ID3 tags and embedded cover art, and remembers the path between launches.
- **Playlists.** Build them by hand, or import.
- **Import from anywhere.** Paste an Audius link, a list of song names, or connect your Spotify account and pull your playlists across.
- **Make it yours.** Your own wallpaper, blur and darkness sliders, any accent colour.
- **Fast on old hardware.** A "reduce effects" switch turns off the glass blur, which is the single biggest win on an older laptop.
- **Keyboard driven.** Space, arrows, `n`/`p`, `s`, `r`, `l`, `/`.

### What Ember deliberately does not do

It does not download audio from Spotify or YouTube. Those services encrypt their
streams, and tools that break that encryption get taken down. Ember reads your
*playlists* and plays the matching tracks from sources that allow it. That is a
design decision, not a missing feature.

---

## Download

Grab an installer from the [Releases page](https://github.com/YOUR-USERNAME/ember/releases).

| Platform | File |
|---|---|
| Windows | `.msi` |
| macOS | `.dmg` |
| Linux | `.AppImage` or `.deb` |

The builds are unsigned, so Windows SmartScreen and macOS Gatekeeper will warn
you the first time. On macOS: right-click the app → **Open**.

---

## Build from source

### Prerequisites

| | |
|---|---|
| [Rust](https://rustup.rs) | stable, 1.77 or newer |
| [Node.js](https://nodejs.org) | 18 or newer |

<details>
<summary><b>Linux also needs the webview libraries</b> (click to expand)</summary>

```bash
# Debian / Ubuntu / Mint
sudo apt update
sudo apt install libwebkit2gtk-4.1-dev build-essential curl wget file \
  libxdo-dev libssl-dev libayatana-appindicator3-dev librsvg2-dev

# Fedora
sudo dnf install webkit2gtk4.1-devel openssl-devel curl wget file \
  libappindicator-gtk3-devel librsvg2-devel
sudo dnf group install "C Development Tools and Libraries"

# Arch
sudo pacman -S webkit2gtk-4.1 base-devel curl wget file openssl \
  appmenu-gtk-module libappindicator-gtk3 librsvg
```

</details>

<details>
<summary><b>Windows also needs the C++ build tools</b></summary>

Install [Visual Studio C++ Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/)
and tick **Desktop development with C++**. WebView2 is already on Windows 11
and up-to-date Windows 10.

</details>

### Run it

```bash
git clone https://github.com/YOUR-USERNAME/ember.git
cd ember
npm install
npm run dev
```

The first run compiles Rust from scratch and takes a few minutes. Every run
after that is seconds. Edit `src/index.html`, save, and the window reloads.

### Build an installer

```bash
npm run build
```

Output lands in `src-tauri/target/release/bundle/`.

---

## Connecting Spotify

Optional. It reads your playlists and finds the matching tracks — it does not
play Spotify audio.

1. Go to the [Spotify Developer Dashboard](https://developer.spotify.com/dashboard) and sign in.
2. **Create app.** Name and description can be anything.
3. Under **Redirect URIs**, add exactly this and save:
   ```
   http://127.0.0.1:1421/callback
   ```
4. Copy the **Client ID**.
5. In `src/index.html`, find this line and paste it in:
   ```js
   var SPOTIFY_CLIENT_ID = "";   // ← paste your Client ID here
   ```
6. Restart Ember, open the **Import** tab, press **Connect Spotify**.

There is no client secret, and there shouldn't be — a desktop app cannot keep
one, since anyone can unzip it and read the file. Ember uses **PKCE** instead,
where the app proves itself with a one-time random value generated fresh for
every login.

---

## How it works

```
ember/
├── src/
│   └── index.html          the entire app — UI, player, API calls, settings
├── src-tauri/
│   ├── src/main.rs         three native commands, ~200 lines of Rust
│   ├── Cargo.toml          Rust dependencies
│   ├── tauri.conf.json     window size, permissions, bundle settings
│   └── capabilities/       what the window may ask the native side to do
└── .github/workflows/      CI, and release builds for all three platforms
```

`src/index.html` has **no build step and no dependencies**. Open it directly in
a browser and it still works — it just hides the desktop-only features, because
`window.__TAURI__` is undefined there. One file, two modes.

### The three native commands

Each exists because JavaScript genuinely cannot do it, and nothing else is
native.

| Command | What it does |
|---|---|
| `scan_folder` | Walks a folder and its subfolders, returns every audio file |
| `oauth_listen` | Opens the browser, listens on a local port, returns the login code |
| `open_url` | Opens a link in the real browser, never inside the app window |

`oauth_listen` is the interesting one. When you click **Connect Spotify**, Ember
becomes a web server for about ten seconds:

1. Binds `127.0.0.1:1421` — *before* opening the browser, or a fast redirect
   arrives at a closed port
2. Opens Spotify's login page in your real browser
3. Spotify redirects back to that port carrying an authorization code
4. Ember reads one line of HTTP, grabs the code, and replies with a "you can
   close this tab" page

That is all an OAuth redirect has ever been. It is written with a plain TCP
socket and no HTTP library, specifically so the mechanism is visible.

The login page opens in your **real browser**, never inside Ember's own window.
An embedded window has no address bar, so you could not tell a genuine Spotify
page from a convincing fake. That is a security decision, not a convenience one.

### Two config details worth knowing

**`withGlobalTauri: true`** is what lets a plain HTML file call
`window.__TAURI__.core.invoke(...)` with no npm packages and no bundler. Turn it
off and you need a full JavaScript build pipeline.

**`assetProtocol`** is what lets `<audio>` play a file off your own disk.
Browsers block `file://` for good reasons, so Tauri serves local files over its
own `asset://` protocol instead; `convertFileSrc(path)` does the translation.
It must be paired with the `protocol-asset` feature in `Cargo.toml` or the build
refuses to start.

---

## Keyboard shortcuts

| Key | Action |
|---|---|
| `Space` | Play / pause |
| `←` `→` | Seek 5 seconds |
| `↑` `↓` | Volume |
| `n` / `p` | Next / previous |
| `s` | Shuffle |
| `r` | Repeat (off → all → one) |
| `l` | Like current track |
| `/` | Jump to search |

---

## FAQ

<details>
<summary><b>Why can't I play Taylor Swift / Drake / anything from the charts?</b></summary>

No free API gives you major-label music. Anything that claims to is either
scraping YouTube or using unofficial Spotify endpoints — both are copyright
infringement and both get shut down. Ember uses Audius, where artists upload
their own work and choose to make it streamable. Different catalogue, legal
forever.

</details>

<details>
<summary><b>Why isn't YouTube supported?</b></summary>

Reading your YouTube playlists works the same way Spotify does. Playing them
means embedding YouTube's official iframe player, which is allowed but turns
Ember into a browser wrapper. Extracting the audio is not allowed. Left out on
purpose — the Spotify code in `index.html` is the template if you want it.

</details>

<details>
<summary><b>It stutters on my laptop.</b></summary>

Settings → **Reduce effects**. Backdrop blur is redrawn by the GPU on every
single frame; turning it off is usually the whole fix.

</details>

<details>
<summary><b>Why Tauri and not Electron?</b></summary>

Electron bundles an entire copy of Chrome with every app — about 250 MB of RAM
before your code runs. Tauri uses the webview your operating system already has.
Same HTML, roughly a third of the memory.

</details>

<details>
<summary><b>Does it phone home?</b></summary>

No analytics, no accounts, no telemetry. It talks to Audius to fetch music, and
to Spotify only if you connect it. Your settings, playlists and liked tracks
live in local storage on your own machine.

</details>

---

## Contributing

Issues and pull requests welcome — see [CONTRIBUTING.md](CONTRIBUTING.md).

Good first issues: adding a wallpaper preset, a new accent colour, more audio
file extensions in `main.rs`, or a light theme.

---

## Credits

- [Audius](https://audius.co) — the open music network and its free API
- [Tauri](https://tauri.app) — the desktop shell
- [jsmediatags](https://github.com/aadsm/jsmediatags) — ID3 tag reading
- Fonts: [Syne](https://fonts.google.com/specimen/Syne) and [Figtree](https://fonts.google.com/specimen/Figtree)

## License

[MIT](LICENSE) — do what you like with the code.

The **music is not covered by that licence.** Audius tracks belong to the
artists who uploaded them, and the API is free to use on the condition that you
credit them. Ember does that by showing the artist on every track and in the
player. Please keep it that way.
